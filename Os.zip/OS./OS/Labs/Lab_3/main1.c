#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <time.h>

typedef struct {
    long long si;
    long long ei;
    int* size;
    int* primes;
} thread_data;

bool is_prime(int n) {
    if (n <= 1) return false;
    if (n == 2) return true;       
    if (n % 2 == 0) return false;  

    for (int i = 3; i * i <= n; i += 2) {
        if (n % i == 0) return false;
    }
    return true;
}

int* primes_in_range(int start, int end, int *size) {
    int* primes = (int*)malloc((end - start + 1) * sizeof(int));
    *size = 0;

    for (int i = start; i <= end; i++) {
        if (is_prime(i)) {
            primes[*size] = i;
            (*size)++;
        }
    }

    primes = (int*)realloc(primes, *size * sizeof(int));  // Resize array to fit exactly
    return primes;
}

void* primes_thread(void* arg) {
    thread_data* data = (thread_data*)arg;
    data->primes = primes_in_range(data->si, data->ei, data->size);
    return NULL;
}

int main() {
    clock_t start_time, end_time;
    double time_taken;

    int total_size = 0;
    int* total_primes = NULL;
    
    long long start = 1, end = 1000000;
    int num_threads = 5;
    pthread_t threads[num_threads];
    thread_data thread_args[num_threads];

    long long range_size = (end - start + 1) / num_threads;

    start_time = clock();  // Start timing

    // Create threads to compute primes in different ranges
    for (int i = 0; i < num_threads; i++) {
        thread_args[i].si = start + i * range_size;
        thread_args[i].ei = (i == num_threads - 1) ? end : start + (i + 1) * range_size - 1;
        thread_args[i].size = (int*)malloc(sizeof(int));
        thread_args[i].primes = NULL;

        pthread_create(&threads[i], NULL, primes_thread, (void*)&thread_args[i]);
    }

    // Join threads and collect results
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
        total_size += *thread_args[i].size;
        total_primes = (int*)realloc(total_primes, total_size * sizeof(int));
        for (int j = 0; j < *thread_args[i].size; j++) {
            total_primes[total_size - *thread_args[i].size + j] = thread_args[i].primes[j];
        }
        free(thread_args[i].size);
        free(thread_args[i].primes);
    }

    end_time = clock();  // End timing
    time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    // Print all prime numbers
    printf("Prime numbers between %lld and %lld are:\n", start, end);
    for (int i = 0; i < total_size; i++) {
        printf("%d ", total_primes[i]);
    }
    printf("\n");

    // Print time taken
    printf("Time taken for multi-threaded execution: %f seconds\n", time_taken);

    // Clean up
    free(total_primes);
    
    return 0;
}

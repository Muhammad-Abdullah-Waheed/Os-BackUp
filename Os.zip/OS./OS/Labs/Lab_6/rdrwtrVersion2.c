#include <stdio.h>
#include "queue.h"
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <time.h>

Element Reader;
Element Writer;
Queue queue;

int readerCount = 0;
int writerCount = 0;
pthread_mutex_t queueLock;
pthread_mutex_t readerCountLock;
pthread_mutex_t writerCountLock;
pthread_mutex_t memoryLock;
pthread_mutex_t tryRead;

// ReaderWriter_1
void Reader1()
{
    do
    {
        pthread_mutex_lock(&tryRead);

        {
            pthread_mutex_lock(&queueLock);
            if (peek(&queue).name == Reader.name)
            {
                // dequeue the top element of the queue.
            }

            pthread_mutex_unlock(&queueLock);

            pthread_mutex_lock(&readerCountLock);
            readerCount++;
            if (readerCount == 1)
            {
                pthread_mutex_lock(&memoryLock);
            }
            pthread_mutex_unlock(&readerCountLock);
        }

        pthread_mutex_unlock(&tryRead);

        // Read()                     --- this function read the data from the Shared memory.

        pthread_mutex_lock(&readerCountLock);
        readerCount++;
        if (readerCount == 0)
        {
            pthread_mutex_unlock(&memoryLock);
        }
        pthread_mutex_unlock(&readerCountLock);

    } while (1);
}

void Writer1()
{
    do
    {
        pthread_mutex_lock(&writerCountLock);

        writerCount++;
        if (writerCount == 1)
        {
            pthread_mutex_lock(&tryRead);
        }

        pthread_mutex_unlock(&writerCountLock);

        pthread_mutex_lock(&queueLock);
        if (peek(&queue).name == Writer.name)
        {
            // dequeue the top element of the queue.
        }
        pthread_mutex_unlock(&queueLock);

        pthread_mutex_lock(&memoryLock);
        // Writer()               ---- this function will write data to the Shared memory.

        pthread_mutex_unlock(&memoryLock);

        pthread_mutex_lock(&writerCountLock);

        writerCount--;
        if (writerCount == 0)
        {
            pthread_mutex_lock(&tryRead);
        }

        pthread_mutex_unlock(&writerCountLock);

    } while (1);
}
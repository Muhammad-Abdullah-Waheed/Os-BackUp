#ifndef QUEUE_H
#define QUEUE_H

// Define a sample structure (replace with your desired structure)
typedef struct {
    int id;
    char name[30];
} Element;

// Queue structure
typedef struct {
    Element* data;
    int front;
    int rear;
    int size;
    int capacity;
} Queue;

// Function prototypes
Queue* createQueue();
void enqueue(Queue* queue, Element element);
Element dequeue(Queue* queue);
Element peek(Queue* queue);
int isFull(Queue* queue);
int isEmpty(Queue* queue);
void resizeQueue(Queue* queue);
void freeQueue(Queue* queue);

#endif // QUEUE_H

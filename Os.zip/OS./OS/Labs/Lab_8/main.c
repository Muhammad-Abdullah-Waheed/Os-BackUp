#include<stdio.h>
#include<stdlib.h>

extern char ** environ;

int main(int argc,char* arg[])
{
    char ** env = environ;
    printf("%d",argc);
    for(int i=0;i<argc;++i)
    {
        printf("%s\n",arg[i]);
    }
    while(*env)
        {
            printf("%s",*env);
            (*env)++;
        }
    return 0;
}


// cat/etc/envirnment

// set env
// get env

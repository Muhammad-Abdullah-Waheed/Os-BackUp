#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <pthread.h>
#include <errno.h>
#include "Queue.h"
#include <semaphore.h>
#include "vector.h"
#include <stdbool.h>


#define PORT 11000
#define BUFFER_SIZE 1024
#define STORAGE_LIMIT 10240 // 10 KB
#define SERVER_DIR "/home/abdullah/Desktop/OS/Labs/lab_9/server_files/"
#define CLIENTS_FILE "/home/abdullah/Desktop/OS/Labs/lab_9/server_files/clients_info.txt"

Queue* request_queue;
Vector *client_vector;


#define MAX_USERS 100  

// Mutex and semaphores for each user
pthread_mutex_t read_count_lock[MAX_USERS];
pthread_mutex_t queues_lock[MAX_USERS];
sem_t resource_sem[MAX_USERS];
int read_count[MAX_USERS];  // Track readers per user



typedef struct {
    Queue *queue;
    pthread_t thread;
    sem_t queue_sem;
    bool thread_active;
} ClientQueue;

ClientQueue user_queues[MAX_USERS];


int reader_count = 0;
int max_id = 0;

void handle_download(Request *req);
void handle_view(Request *req);
void handle_upload(Request *req);

void *process_requests(void *arg);
void handle_client(int new_socket);
// void handle_upload(int new_socket, const char *file_name, char *client_dir);
// void handle_download(int new_socket, const char *file_name, char *client_dir);
// void handle_view(int new_socket, char *client_dir);
void *client_handler(void *socket);
int authenticate_client(int new_socket, char *client_dir,char *username,char *pasword,char *userid);

// Helper function prototypes
int authenticate_and_initialize(int socket, char *client_dir, char *username, char *password, char *userid);
Request parse_request(int socket, char *buffer, char *username, char *userid);
void process_request_directly(Request *req);
void handle_client_queue(int user_id, Request req);
void cleanup_client(int user_id, int socket);
void *process_client_queue(void *arg);



// Initialize locks and semaphores
void initialize_locks() {
    for (int i = 0; i < MAX_USERS; i++) {
        pthread_mutex_init(&read_count_lock[i], NULL);
        pthread_mutex_init(&queues_lock[i], NULL);
        sem_init(&resource_sem[i], 0, 1);  // Semaphore initialized to 1
        read_count[i] = 0;  // Initialize reader count to 0
    }
}

// Clean up locks and semaphores
void cleanup_locks() {
    for (int i = 0; i < MAX_USERS; i++) {
        pthread_mutex_destroy(&read_count_lock[i]);
        pthread_mutex_destroy(&queues_lock[i]);
        sem_destroy(&resource_sem[i]);
    }
}

void start_read(int user_id) 
{
    pthread_mutex_lock(&read_count_lock[user_id]);  // Lock read count update
    read_count[user_id]++;
    if (read_count[user_id] == 1) {  // First reader locks resource
        sem_wait(&resource_sem[user_id]);
    }
    pthread_mutex_unlock(&read_count_lock[user_id]);  // Unlock read count update
}

// End Read - Releases reader lock
void end_read(int user_id) {
    pthread_mutex_lock(&read_count_lock[user_id]);  // Lock read count update
    read_count[user_id]--;
    if (read_count[user_id] == 0) {  // Last reader unlocks resource
        sem_post(&resource_sem[user_id]);
    }
    pthread_mutex_unlock(&read_count_lock[user_id]);  // Unlock read count update
}

// Start Write - Ensures exclusive access to writers
void start_write(int user_id) {
    sem_wait(&resource_sem[user_id]);  // Only one writer at a time
}

// End Write - Releases writer lock
void end_write(int user_id) {
    sem_post(&resource_sem[user_id]);  // Allow other operations
}

int authenticate_client(int new_socket, char *client_dir, char *username, char *password, char *userid)
{
    char stored_user[BUFFER_SIZE], stored_pass[BUFFER_SIZE], stored_userid[30];
    FILE *file;
    int authenticated = 0;
    int max_id = 0; // To track the maximum ID

    // Ask for username and password
    write(new_socket, "Enter Username: ", 16);
    read(new_socket, username, BUFFER_SIZE);
    write(new_socket, "Enter Password: ", 16);
    read(new_socket, password, BUFFER_SIZE);

    // Trim newline characters if present
    username[strcspn(username, "\n")] = '\0';
    password[strcspn(password, "\n")] = '\0';

    // Check if client info file exists
    if ((file = fopen(CLIENTS_FILE, "r")) != NULL)
    {
        // Read the maximum ID from the first line of the file (if it exists)
        if (fscanf(file, "%d", &max_id) != EOF)
        {
            while (fscanf(file, "%s %s %s", stored_user, stored_pass, stored_userid) != EOF)
            {
                if (strcmp(username, stored_user) == 0 && strcmp(password, stored_pass) == 0)
                {
                    authenticated = 1;
                    strncpy(userid, stored_userid, 30); // Store the user ID for later use
                    break;
                }
            }
        }
        fclose(file);
    }

    // strtol(str, &endptr, 10);
    if (!authenticated)
    {
        // New client, store the username, password, and user ID
        write(new_socket, "$NO SUCCESS$NEW_USER$", 18);
        char a[4];
        read(new_socket, a, 3);

        if (strncmp(a, "yes", 3) == 0)
        {
            max_id++; // Increment the max ID for the new user

            file = fopen(CLIENTS_FILE, "a");
            if (file != NULL)
            {
                snprintf(userid, 30, "%d", max_id); // Assign the new ID
                fprintf(file, "%s %s %s\n", username, password, userid); // Save the new user data with the ID
                fclose(file);

                // Update the max ID in the file (rewrite at the beginning)
                file = fopen(CLIENTS_FILE, "r+");
                if (file != NULL)
                {
                    fprintf(file, "%d\n", max_id); // Save the updated max ID
                    fclose(file);
                }
            }
        }
        else
        {
            return -1;
        }
    }
    else
    {
        write(new_socket, "$SUCCESS$EXISTING_USER$", 22);
    }

    // Create directory for the client if not exists
    snprintf(client_dir, BUFFER_SIZE, "%s%s/", SERVER_DIR, username);
    if (mkdir(client_dir, 0777) && errno != EEXIST)
    {
        perror("mkdir");
        return -1;
    }

    return 0;
}

// Main client handler function
void *client_handler(void *socket) {
    int new_socket = *(int *)socket;
    char client_dir[BUFFER_SIZE] = {0}, username[BUFFER_SIZE] = {0}, password[BUFFER_SIZE] = {0}, userid[30] = {0};
    char buffer[BUFFER_SIZE] = {0};

    if (authenticate_and_initialize(new_socket, client_dir, username, password, userid) == -1) {
        close(new_socket);
        return NULL;
    }

    int user_id = atoi(userid);
    increment_client_count(client_vector, user_id);

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        read(new_socket, buffer, BUFFER_SIZE);

        Request req = parse_request(new_socket, buffer, username, userid);
        if (strcmp(req.requestType, "invalid") == 0) {
            write(new_socket, "$FAILURE$INVALID_COMMAND$", 25);
            continue;
        }

        int client_count = get_client_count(client_vector, user_id);
        if (client_count == 1) {
            process_request_directly(&req);
        } else {
            handle_client_queue(user_id, req);
        }

        sleep(4);  // Simulate some delay
    }

    cleanup_client(user_id, new_socket);
    return NULL;
}

int authenticate_and_initialize(int socket, char *client_dir, char *username, char *password, char *userid) {
    if (authenticate_client(socket, client_dir, username, password, userid) == -1) {
        return -1;  // Authentication failed
    }
    return 0;
}

Request parse_request(int socket, char *buffer, char *username, char *userid) {
    Request req;
    req.clientSocket = socket;
    strcpy(req.username, username);
    strcpy(req.userid, userid);

    if (strncmp(buffer, "$UPLOAD$", 8) == 0) {
        strcpy(req.requestType, "upload");
        strcpy(req.fileName, buffer + 8);
    } else if (strncmp(buffer, "$DOWNLOAD$", 10) == 0) {
        strcpy(req.requestType, "download");
        strcpy(req.fileName, buffer + 10);
    } else if (strncmp(buffer, "$VIEW$", 6) == 0) {
        strcpy(req.requestType, "view");
    } else if (strncmp(buffer, "$EXIT$", 6) == 0) {
        decrement_client_count(client_vector, atoi(userid));
        strcpy(req.requestType, "exit");
    } else {
        strcpy(req.requestType, "invalid");
    }
    return req;
}

void process_request_directly(Request *req) {
    if (strcmp(req->requestType, "upload") == 0) {
        handle_upload(req);
    } else if (strcmp(req->requestType, "download") == 0) {
        handle_download(req);
    } else if (strcmp(req->requestType, "view") == 0) {
        handle_view(req);
    }
}

void handle_client_queue(int user_id, Request req) {
    if (!user_queues[user_id].thread_active) {
        user_queues[user_id].queue = createQueue();
        sem_init(&user_queues[user_id].queue_sem, 0, 0);
        user_queues[user_id].thread_active = true;
        pthread_create(&user_queues[user_id].thread, NULL, process_client_queue, &user_id);
    }

    pthread_mutex_lock(&queues_lock[user_id]);
    enqueue(user_queues[user_id].queue, req);
    pthread_mutex_unlock(&queues_lock[user_id]);
    sem_post(&user_queues[user_id].queue_sem);
}

void cleanup_client(int user_id, int socket) {
    if (get_client_count(client_vector, user_id) < 2 && user_queues[user_id].thread_active) {
        user_queues[user_id].thread_active = false;
        sem_post(&user_queues[user_id].queue_sem);
        pthread_join(user_queues[user_id].thread, NULL);
        freeQueue(user_queues[user_id].queue);
        sem_destroy(&user_queues[user_id].queue_sem);
    }
    close(socket);
}

void *process_client_queue(void *arg) {
    int user_id = *(int *)arg;

    while (user_queues[user_id].thread_active) {
        // Wait until there's a request in the queue
        sem_wait(&user_queues[user_id].queue_sem);

        // Exit condition: if the thread is no longer active and the queue is empty
        if (!user_queues[user_id].thread_active && isEmpty(user_queues[user_id].queue)) {
            break;
        }

        // Lock the queue and dequeue the next request
        pthread_mutex_lock(&queues_lock[user_id]);
        if (isEmpty(user_queues[user_id].queue)) {
            pthread_mutex_unlock(&queues_lock[user_id]);
            continue;
        }
        Request req = dequeue(user_queues[user_id].queue);
        pthread_mutex_unlock(&queues_lock[user_id]);

        // Process the request based on its type
        if (strcmp(req.requestType, "upload") == 0) {
            start_write(user_id);
            handle_upload(&req);
            end_write(user_id);
        } else if (strcmp(req.requestType, "download") == 0) {
            start_read(user_id);
            handle_download(&req);
            end_read(user_id);
        } else if (strcmp(req.requestType, "view") == 0) {
            start_read(user_id);
            handle_view(&req);
            end_read(user_id);
        }
    }

    return NULL;
}

void handle_view(Request *req) {
    char client_dir[BUFFER_SIZE];
    snprintf(client_dir, sizeof(client_dir), "%s%s/", SERVER_DIR, req->username);

    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char file_path[BUFFER_SIZE];
    char response[BUFFER_SIZE * 2] = ""; // Larger buffer for multiple files
    int files_found = 0;

    dir = opendir(client_dir);
    if (!dir) {
        write(req->clientSocket, "$FAILURE$DIR_OPEN_ERROR$", 24);
        return;
    }
    // write(req->clientSocket, "$SUCCESS$", 9);
    // read()
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            snprintf(file_path, sizeof(file_path), "%s%s", client_dir, entry->d_name);
            if (stat(file_path, &file_stat) == 0) {
                files_found = 1;
                char mod_time[20];
                strftime(mod_time, sizeof(mod_time), "%Y-%m-%d %H:%M:%S", localtime(&file_stat.st_mtime));
                snprintf(response + strlen(response), sizeof(response) - strlen(response),
                         "File: %s, Size: %ld bytes, Last Modified: %s\n",
                         entry->d_name, file_stat.st_size, mod_time);
            }
        }
    }

    closedir(dir);

    if (files_found) {
        write(req->clientSocket, response, strlen(response)); // Send the file list
    } else {
        write(req->clientSocket, "$FAILURE$NO_CLIENT_DATA_FOUND$", 30); // No files found
    }
}

void handle_upload(Request *req) {
    char client_dir[BUFFER_SIZE];
    snprintf(client_dir, sizeof(client_dir), "%s%s/", SERVER_DIR, req->username);

    char data[STORAGE_LIMIT];
    char file_path[BUFFER_SIZE];
    FILE *file;
    struct stat file_stat;
    DIR *dir;
    struct dirent *entry;
    size_t total_size = 0;

    // Check storage space
    dir = opendir(client_dir);
    if (!dir) {
        write(req->clientSocket, "$FAILURE$DIR_OPEN_ERROR$", 24);
        return;
    }
    write(req->clientSocket, "$SUCCESS$", 9);

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            snprintf(file_path, sizeof(file_path), "%s%s", client_dir, entry->d_name);
            if (stat(file_path, &file_stat) == 0) {
                total_size += file_stat.st_size;
            }
        }
    }
    closedir(dir);

    if (total_size >= STORAGE_LIMIT) {
        write(req->clientSocket, "$FAILURE$LOW_SPACE$", 20);
        return;
    }

    snprintf(file_path, sizeof(file_path), "%s%s", client_dir, req->fileName);
    // write(req->clientSocket, "$SUCCESS$", 9);

    ssize_t data_size = read(req->clientSocket, data, STORAGE_LIMIT);
    data[data_size + 1] = '\0';

    if (data_size <= 0) {
        write(req->clientSocket, "$FAILURE$UPLOAD_FAILED$", 22);
        return;
    }

    file = fopen(file_path, "wb");
    if (!file) {
        write(req->clientSocket, "$FAILURE$SAVE_ERROR$", 20);
        return;
    }

    fwrite(data, 1, data_size, file);
    fclose(file);

    write(req->clientSocket, "$SUCCESS$", 9);
}

void handle_download(Request *req) {
    char client_dir[BUFFER_SIZE];

    snprintf(client_dir, sizeof(client_dir), "%s/", SERVER_DIR);
    // strcat(client_dir,req->username);
    snprintf(client_dir, sizeof(client_dir), "%s%s/", SERVER_DIR, req->username);

    char file_path[BUFFER_SIZE];
    char file_data[2048];
    FILE *file;
    ssize_t data_size;

    // strcat(client_dir,req->fileName);
    // Construct the full path of the file in the server directory
    snprintf(file_path, sizeof(file_path), "%s%s", client_dir, req->fileName);

    // Open the file for reading
    file = fopen(file_path, "rb");
    if (!file) {
        // If the file doesn't exist, send failure message
        write(req->clientSocket, "$FAILURE$FILE_NOT_FOUND$", 25);
        return;
    }

    char response[20] = {0};
    // Notify the client that the file exists
    write(req->clientSocket, "$SUCCESS$", 9);

    int readsize = read(req->clientSocket, response, strlen("send data"));
    if (strncmp(response, "send data", strlen("send data")) != 0) {
        write(req->clientSocket, "$NO SUCCESS$", 12);
        return;
    }

    // Read the file content and send it to the client
    if ((data_size = fread(file_data, 1, BUFFER_SIZE, file)) > 0) {
        file_data[data_size + 1] = '\0';
        write(req->clientSocket, file_data, data_size);
    }

    fclose(file);
}

/*
#define THREAD_THRESHOLD 2  // New thread for every 2 users

typedef struct {
    Queue *queue;
    pthread_t *threads;     // Array of threads to handle requests
    sem_t queue_sem;
    bool thread_active;
    int user_count;         // Track active user count per user ID
    int thread_count;       // Track thread count per user ID
} ClientQueue;

ClientQueue user_queues[MAX_USERS];
pthread_mutex_t user_count_lock[MAX_USERS]; // Mutex for updating user count

// Initialize ClientQueue and synchronization primitives
void initialize_client_queues() {
    for (int i = 0; i < MAX_USERS; i++) {
        user_queues[i].queue = createQueue();  // Assuming createQueue() initializes the queue
        sem_init(&user_queues[i].queue_sem, 0, 0);
        user_queues[i].thread_active = true;
        user_queues[i].user_count = 0;
        user_queues[i].thread_count = 0;
        user_queues[i].threads = NULL;  // Initialize thread array to NULL
        pthread_mutex_init(&user_count_lock[i], NULL);
    }
}

// Cleanup ClientQueue and synchronization primitives
void cleanup_client_queues() {
    for (int i = 0; i < MAX_USERS; i++) {
        user_queues[i].thread_active = false;
        sem_destroy(&user_queues[i].queue_sem);
        pthread_mutex_destroy(&user_count_lock[i]);
        free(user_queues[i].threads); // Free dynamically allocated threads
    }
}

// Dynamic thread creation function
void create_thread_for_user(int user_id) {
    pthread_mutex_lock(&user_count_lock[user_id]);
    user_queues[user_id].user_count++;

    // Check if new thread is needed
    if (user_queues[user_id].user_count % THREAD_THRESHOLD == 1) {
        user_queues[user_id].thread_count++;
        user_queues[user_id].threads = realloc(user_queues[user_id].threads,
                                               user_queues[user_id].thread_count * sizeof(pthread_t));
        int thread_index = user_queues[user_id].thread_count - 1;

        // Create a new thread to process client queue
        if (pthread_create(&user_queues[user_id].threads[thread_index], NULL,
                           process_client_queue, &user_queues[user_id]) != 0) {
            perror("Failed to create thread");
        }
    }
    pthread_mutex_unlock(&user_count_lock[user_id]);
}

// Thread function to process requests in client queue
void *process_client_queue(void *arg) {
    ClientQueue *client_queue = (ClientQueue *)arg;

    while (client_queue->thread_active) {
        sem_wait(&client_queue->queue_sem);  // Wait for requests in the queue

        // Exit if queue is empty and thread is no longer active
        if (!client_queue->thread_active && isEmpty(client_queue->queue)) {
            break;
        }

        // Dequeue and process requests
        Request req = dequeue(client_queue->queue);

        if (strcmp(req.requestType, "upload") == 0 || strcmp(req.requestType, "download") == 0) {
            start_write(req.user_id);
            if (strcmp(req.requestType, "upload") == 0) {
                handle_upload(&req);
            } else if (strcmp(req.requestType, "download") == 0) {
                handle_download(&req);
            }
            end_write(req.user_id);
        } else if (strcmp(req.requestType, "view") == 0) {
            start_read(req.user_id);
            handle_view(&req);
            end_read(req.user_id);
        }
    }
    return NULL;
}

// Function to add a new user and process the request
void add_user_and_process(int user_id, Request req) {
    enqueue(user_queues[user_id].queue, req);
    sem_post(&user_queues[user_id].queue_sem);  // Signal that a request is available
    create_thread_for_user(user_id);  // Dynamically create threads based on user count
}

*/

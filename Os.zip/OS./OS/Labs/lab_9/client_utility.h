#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 11000
#define BUFFER_SIZE 1024
#define CLIENT_DIR "/home/abdullah/Desktop/OS/Labs/lab_9/client_files/"
char username[BUFFER_SIZE] = {0}, password[BUFFER_SIZE] = {0};


void upload_file(int sock, const char *file_path);
void download_file(int sock, const char *file_name);
int encode_rle(const char *input, char *output);
int decode_rle(const char *input, char *output);




void upload_file(int sock, const char *file_path)
{
    char full_path[BUFFER_SIZE];
    char file_data[BUFFER_SIZE];
    char encoded_data[BUFFER_SIZE * 2];
    FILE *file;
    size_t size;

    // Construct the full path to the file in the client directory
    snprintf(full_path, sizeof(full_path), "%s%s", CLIENT_DIR, file_path);

    // Open the file
    file = fopen(full_path, "rb");
    if (!file)
    {
        printf("Error: File not found.\n");
        write(sock, "$FAILURE$FILE_NOT_FOUND$", 25);
        return;
    }

    // Read the file data
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    rewind(file);
    //printf(" -----  ---- %d",size);
    fread(file_data, 1, size, file);
    file_data[size]=0;
    file_data[size+1]=0;
    file_data[size+2]=0;

    fclose(file);

    int encode_size = encode_rle(file_data, encoded_data);


    // Send the file data to the server
    write(sock, encoded_data, encode_size);
    sleep(1);
    // Get the server's response
    char server_response[BUFFER_SIZE];
    read(sock, server_response, BUFFER_SIZE);
    printf("Server response upload: %s\n", server_response);
}

void download_file(int sock, const char *file_name) {
    char full_path[BUFFER_SIZE];
    char file_data[BUFFER_SIZE];
    char encoded_data[BUFFER_SIZE * 2];
    FILE *file;
    ssize_t data_size;

    // Construct the full path where the file will be saved in the client directory
    snprintf(full_path, sizeof(full_path), "%s%s", CLIENT_DIR, file_name);

    // Open the file for writing in binary mode
    file = fopen(full_path, "wb");
    if (!file) {
        printf("Error: Could not save the file.\n");
        return;
    }

    // Loop to read and write chunks of the file
    if((data_size = read(sock, file_data, BUFFER_SIZE)) > 0) {
        int decode_size = decode_rle(file_data, encoded_data); // Decode the received data
        fwrite(encoded_data, 1, decode_size, file);            // Write decoded data to file
    }

    if (data_size < 0) {
        printf("Error: Failed to receive data.\n");
    } else {
        printf("File '%s' downloaded successfully.\n", file_name);
    }

    fclose(file);  // Close the file after download is complete
}
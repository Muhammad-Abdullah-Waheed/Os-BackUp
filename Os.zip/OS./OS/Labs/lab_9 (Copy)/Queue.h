
typedef struct {
    int clientSocket;
    char requestType[10];  // e.g., upload, download, view
    char fileName[200];     // file to act on
    char username[30];
    char userid[30];
} Request;

// Queue structure
typedef struct {
    Request* data;
    int front;
    int rear;
    int size;
    int capacity;
} Queue;

#define INITIAL_CAPACITY 2

// Function to create a new queue
Queue* createQueue() {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    queue->capacity = INITIAL_CAPACITY;
    queue->front = queue->size = 0;
    queue->rear = queue->capacity - 1;
    queue->data = (Request*)malloc(queue->capacity * sizeof(Request));
    return queue;
}

// Function to check if the queue is full
int isFull(Queue* queue) {
    return queue->size == queue->capacity;
}


// Function to check if the queue is empty
int isEmpty(Queue* queue) {
    return queue->size == 0;
}

// Function to resize the queue when it's full
void resizeQueue(Queue* queue) {
    int new_capacity = queue->capacity * 2;
    Request* new_data = (Request*)malloc(new_capacity * sizeof(Request));

    // Copy the elements to the new array
    for (int i = 0; i < queue->size; i++) {
        new_data[i] = queue->data[(queue->front + i) % queue->capacity];
    }

    free(queue->data);  // Free the old memory
    queue->data = new_data;
    queue->capacity = new_capacity;
    queue->front = 0;
    queue->rear = queue->size - 1;
}

// Function to add a request to the queue
void enqueue(Queue* queue, Request request) {
    if (isFull(queue)) {
        printf("Queue is full, resizing...\n");
        resizeQueue(queue);
    }

    queue->rear = (queue->rear + 1) % queue->capacity;
    queue->data[queue->rear] = request;
    queue->size++;
}

// Function to remove a request from the queue
Request dequeue(Queue* queue) {
    if (isEmpty(queue)) {
        printf("Queue is empty, cannot dequeue.\n");
        exit(EXIT_FAILURE);  // Exit on error
    }

    Request request = queue->data[queue->front];
    queue->front = (queue->front + 1) % queue->capacity;
    queue->size--;
    return request;
}

// Function to return a copy of the request at the front of the queue
Request peek(Queue* queue) {
    if (isEmpty(queue)) {
        printf("Queue is empty, cannot peek.\n");
        exit(EXIT_FAILURE);  // Exit on error
    }

    return queue->data[queue->front];
}

// Function to free the memory allocated to the queue
void freeQueue(Queue* queue) {
    free(queue->data);
    free(queue);
}





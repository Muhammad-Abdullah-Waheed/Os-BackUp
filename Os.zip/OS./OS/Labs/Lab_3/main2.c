#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

bool is_prime(int n) {
    if (n <= 1) return false;
    if (n == 2) return true;       
    if (n % 2 == 0) return false;  

    for (int i = 3; i * i <= n; i += 2) {
        if (n % i == 0) return false;
    }
    return true;
}

int* primes_in_range(int start, int end, int *size) {
    int* primes = (int*)malloc((end - start + 1) * sizeof(int));
    *size = 0;

    for (int i = start; i <= end; i++) {
        if (is_prime(i)) {
            primes[*size] = i;
            (*size)++;
        }
    }

    primes = (int*)realloc(primes, *size * sizeof(int));  // Resize array to fit exactly
    return primes;
}

int main() {
    clock_t start_time, end_time;
    double time_taken;

    int start = 1, end = 1000000;
    int size = 0;
    
    start_time = clock();  // Start timing

    int* primes = primes_in_range(start, end, &size);

    end_time = clock();  // End timing
    time_taken = (double)(end_time - start_time) / CLOCKS_PER_SEC;

    // Print all prime numbers
    printf("Prime numbers between %d and %d are:\n", start, end);
    for (int i = 0; i < size; i++) {
        printf("%d ", primes[i]);
    }
    printf("\n");

    // Print time taken
    printf("Time taken for single-threaded execution: %f seconds\n", time_taken);

    // Clean up
    free(primes);
    
    return 0;
}






// For main1.c:
// Time taken for multi-threaded execution: 0.172086 seconds

// For main2.c:
// Time taken for single-threaded execution: 0.152385 seconds
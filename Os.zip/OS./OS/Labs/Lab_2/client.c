#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PORT 11000
#define BUFFER_SIZE 1024
#define CLIENT_DIR "/home/abdullah/Desktop/OS/Labs/Lab_2/client_files/"

void upload_file(int sock, const char *file_path);
void download_file(int sock, const char *file_name);

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};
    char command[BUFFER_SIZE], file_path[BUFFER_SIZE];

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("\nConnection Failed \n");
        return -1;
    }

    // Command prompt for user
    printf("Enter command ($UPLOAD$<file_path> or $DOWNLOAD$<file_name> or $VIEW$): ");
    scanf("%s", command);  // Expect the full command like $UPLOAD$sample.txt

    // Check for $UPLOAD$ command
    if (strncmp(command, "$UPLOAD$", 8) == 0) {
        // Extract file path after the $UPLOAD$ prefix
        strcpy(file_path, command + 8);

        // Send the upload command to server
        write(sock, command, strlen(command));

        // Wait for server response
        read(sock, buffer, BUFFER_SIZE);
        if (strncmp(buffer, "$SUCCESS$", 9) == 0) {
            upload_file(sock, file_path);  // Proceed with file upload
        } else {
            printf("Server response: %s\n", buffer);
        }
    }
    // Check for $DOWNLOAD$ command
    else if (strncmp(command, "$DOWNLOAD$", 10) == 0) {
        // Extract file name after the $DOWNLOAD$ prefix
        strcpy(file_path, command + 10);

        // Send the download command to server
        write(sock, command, strlen(command));

        // Wait for server response and handle download
        read(sock, buffer, BUFFER_SIZE);
        if (strncmp(buffer, "$SUCCESS$", 9) == 0) {
            download_file(sock, file_path);  // Proceed with file download
        } else {
            printf("Server response: %s\n", buffer);
        }
    }
    else if (strncmp(command, "$VIEW$", 6) == 0) {
        // Send the $VIEW$ command to the server
        write(sock, command, strlen(command));

        // Receive the server's response and display it
        ssize_t bytes_read;
        while ((bytes_read = read(sock, buffer, BUFFER_SIZE)) > 0) {
            buffer[bytes_read] = '\0';  // Null-terminate the response
            printf("%s", buffer);
        }
    }
    // Invalid command handling
    else {
        printf("Invalid command! Please use $UPLOAD$, $DOWNLOAD$, $VIEW$, or $HELP$.\n");
    }

    close(sock);
    return 0;
}

void upload_file(int sock, const char *file_path) {
    char full_path[BUFFER_SIZE];
    char file_data[BUFFER_SIZE];
    FILE *file;
    size_t size;

    // Construct the full path to the file in the client directory
    snprintf(full_path, sizeof(full_path), "%s%s", CLIENT_DIR, file_path);

    // Open the file
    file = fopen(full_path, "rb");
    if (!file) {
        printf("Error: File not found.\n");
        write(sock, "$FAILURE$FILE_NOT_FOUND$", 25);
        return;
    }

    // Read the file data
    fseek(file, 0, SEEK_END);
    size = ftell(file);
    rewind(file);

    fread(file_data, 1, size, file);
    fclose(file);

    // Send the file data to the server
    write(sock, file_data, size);

    // Get the server's response
    char server_response[BUFFER_SIZE];
    read(sock, server_response, BUFFER_SIZE);
    printf("Server response: %s\n", server_response);
}

void download_file(int sock, const char *file_name) {
    char full_path[BUFFER_SIZE];
    char file_data[BUFFER_SIZE];
    FILE *file;
    ssize_t data_size;

    // Construct the full path where the file will be saved in the client directory
    snprintf(full_path, sizeof(full_path), "%s%s", CLIENT_DIR, file_name);

    // Receive the file data from the server
    data_size = read(sock, file_data, BUFFER_SIZE);
    if (data_size <= 0) {
        printf("Error: No data received for download.\n");
        return;
    }

    // Save the file data to the client's directory
    file = fopen(full_path, "wb");
    if (file) {
        fwrite(file_data, 1, data_size, file);
        fclose(file);
        printf("File '%s' downloaded successfully.\n", file_name);
    } else {
        printf("Error: Could not save the file.\n");
    }
}

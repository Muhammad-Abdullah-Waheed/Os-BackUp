#include <stdio.h>

void intro(char name[], char l_name[], int age)
{
    printf("My name is %s %s and I am %d years old..\n", name, l_name, age);
}

int main() {
    char first_name[] = "Muhammad Abdullah";
    char last_name[] = "Waheed";
    int age = 20;
    void (*func_ptr)(char[], char[], int) = intro;

    (*func_ptr)(first_name, last_name, age);
    
    return 0;
}
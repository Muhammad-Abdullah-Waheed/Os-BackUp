// server.c
#include "server_utility.h"


int main()
{
    client_vector = create_vector(200);


    request_queue = createQueue();

    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind socket to the address
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 10) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    // setup_server();

    while (1)
    {
        printf("\nWaiting for new connection...\n");
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }

        pthread_t thread_id;
        if (pthread_create(&thread_id, NULL, client_handler, (void *)&new_socket) < 0)
        {
            perror("could not create thread");
            exit(EXIT_FAILURE);
        }
        pthread_detach(thread_id);
    }

    return 0;
}










/*
void *process_requests(void *arg)
{
    while (1)
    {
        char client_path[100];
        Request req;

        sem_wait(&request_sem);
        pthread_mutex_lock(&queue_lock);
        req = dequeue(request_queue);
        pthread_mutex_unlock(&queue_lock);

        snprintf(client_path, sizeof(client_path), "%s%s/", SERVER_DIR, req.username);

        // Decide based on request type
        if (strcmp(req.requestType, "view") == 0)
        {
            // Reader operation (view)
            start_read();

            handle_view(req.clientSocket, client_path);

            end_read();
        }
        else if (strcmp(req.requestType, "upload") == 0)
        {
            // Writer operation (upload/download)
            start_write();

            handle_upload(req.clientSocket, req.fileName, client_path);

            end_write();
        }
        else if (strcmp(req.requestType, "download") == 0)
        {
            // Writer operation (upload/download)
            start_write();

            handle_download(req.clientSocket, req.fileName, client_path);

            end_write();
        }
    }
}

void handle_view(int new_socket, char *client_dir)
{
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char file_path[BUFFER_SIZE];
    char response[BUFFER_SIZE * 2] = ""; // Larger buffer for multiple files
    int files_found = 0;

    dir = opendir(client_dir);
    if (!dir)
    {
        write(new_socket, "$FAILURE$DIR_OPEN_ERROR$", 24);
        return;
    }
    write(new_socket, "$SUCCESS$", 9);

    while ((entry = readdir(dir)) != NULL)
    {
        if (entry->d_type == DT_REG)
        {
            snprintf(file_path, sizeof(file_path), "%s%s", client_dir, entry->d_name);
            if (stat(file_path, &file_stat) == 0)
            {
                files_found = 1;
                char mod_time[20];
                strftime(mod_time, sizeof(mod_time), "%Y-%m-%d %H:%M:%S", localtime(&file_stat.st_mtime));
                snprintf(response + strlen(response), sizeof(response) - strlen(response),
                         "File: %s, Size: %ld bytes, Last Modified: %s\n",
                         entry->d_name, file_stat.st_size, mod_time);
            }
        }
    }

    closedir(dir);

    if (files_found)
    {
        write(new_socket, response, strlen(response)); // Send the file list
    }
    else
    {
        write(new_socket, "$FAILURE$NO_CLIENT_DATA$", 24); // No files found
    }
}

void handle_upload(int new_socket, const char *file_name, char *client_dir)
{
    char data[STORAGE_LIMIT];
    char file_path[BUFFER_SIZE];
    FILE *file;
    struct stat file_stat;
    DIR *dir;
    struct dirent *entry;
    size_t total_size = 0;

    // Check storage space
    dir = opendir(client_dir);
    if (!dir)
    {
        write(new_socket, "$FAILURE$DIR_OPEN_ERROR$", 24);
        return;
    }
    write(new_socket, "$SUCCESS$", 9);

    while ((entry = readdir(dir)) != NULL)
    {
        if (entry->d_type == DT_REG)
        {
            snprintf(file_path, sizeof(file_path), "%s%s", client_dir, entry->d_name);
            if (stat(file_path, &file_stat) == 0)
            {
                total_size += file_stat.st_size;
            }
        }
    }
    closedir(dir);

    if (total_size >= STORAGE_LIMIT)
    {
        write(new_socket, "$FAILURE$LOW_SPACE$", 20);
        return;
    }

    snprintf(file_path, sizeof(file_path), "%s%s", client_dir, file_name);
    write(new_socket, "$SUCCESS$", 9);

    ssize_t data_size = read(new_socket, data, STORAGE_LIMIT);
    data[data_size + 1] = '\0';
    // printf("-----------%d",data_size);
    if (data_size <= 0)
    {
        write(new_socket, "$FAILURE$UPLOAD_FAILED$", 22);
        return;
    }

    file = fopen(file_path, "wb");
    if (!file)
    {
        write(new_socket, "$FAILURE$SAVE_ERROR$", 20);
        return;
    }

    fwrite(data, 1, data_size, file);
    fclose(file);

    write(new_socket, "$SUCCESS$", 9);
}

void handle_download(int new_socket, const char *file_name, char *client_dir)
{
    char file_path[BUFFER_SIZE];
    char file_data[BUFFER_SIZE];
    FILE *file;
    ssize_t data_size;

    // Construct the full path of the file in the server directory
    snprintf(file_path, sizeof(file_path), "%s%s", client_dir, file_name);
    // printf("\n%s\n",file_path);
    //  Open the file for reading
    file = fopen(file_path, "rb");
    if (!file)
    {
        // If the file doesn't exist, send failure message
        write(new_socket, "$FAILURE$FILE_NOT_FOUND$", 25);
        return;
    }

    char reponse[20] = {0};
    // Notify the client that the file exists
    write(new_socket, "$SUCCESS$", 9);
    int readsize = read(new_socket, reponse, strlen("send data"));
    if (strncmp(reponse, "send data", strlen("send data")) != 0)
    {
        write(new_socket, "$NO SUCCESS$", 12);
        printf("bhai dowloading start ka signal nehi diya ?");
        return;
    }

    // Read the file content and send it to the client
    if ((data_size = fread(file_data, 1, BUFFER_SIZE, file)) > 0)
    {
        file_data[data_size + 1] = '\0';
        // printf("\n%s\n",file_data);
        write(new_socket, file_data, data_size);
    }
    else
    {
        printf("bhai handle_downloding my masla ha");
    }

    fclose(file);
}




void *client_handler1(void *socket)
{
    int new_socket = *(int *)socket;
    char buffer[BUFFER_SIZE] = {0};
    char client_dir[BUFFER_SIZE] = {0};
    char username[BUFFER_SIZE] = {0}, password[BUFFER_SIZE] = {0}, userid[30] = {0};

    if (authenticate_client(new_socket, client_dir, username, password, userid) == -1)
    {
        close(new_socket);
        return NULL;
    }
    int user_id = atoi(userid);
    increment_client_count(client_vector, user_id);

    while (1)
    {
        memset(buffer, 0, BUFFER_SIZE);
        read(new_socket, buffer, BUFFER_SIZE);
        Request req;
        req.clientSocket = new_socket;
        strcpy(req.username, username);
        if (strncmp(buffer, "$UPLOAD$", 8) == 0)
        {
            char *file_name = buffer + 8;
            strcpy(req.requestType, "upload");
            strcpy(req.fileName, file_name);
        }
        else if (strncmp(buffer, "$DOWNLOAD$", 10) == 0)
        {
            char *file_name = buffer + 10;
            strcpy(req.requestType, "download");
            strcpy(req.fileName, file_name);
        }
        else if (strncmp(buffer, "$VIEW$", 6) == 0)
        {
            strcpy(req.requestType, "view");
        }
        else if (strncmp(buffer, "$EXIT$", 6) == 0)
        {
            decrement_client_count(client_vector, user_id);
        }
        else
        {
            write(new_socket, "$FAILURE$INVALID_COMMAND$", 25);
        }
        strcpy(req.userid, userid);

        pthread_mutex_lock(&queue_lock);
        enqueue(request_queue, req);
        pthread_mutex_unlock(&queue_lock);

        sem_post(&request_sem);
        sleep(4);
    }

    printf("yyuiuyiu");
    close(new_socket);
    return NULL;
}

*/
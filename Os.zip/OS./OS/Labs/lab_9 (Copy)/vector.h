// vector.h
#ifndef VECTOR_H
#define VECTOR_H

#include "vector.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>  // For debugging



typedef struct {
    int user_id;
    int client_count;  // Count of currently connected clients
} Element;

typedef struct {
    Element *data;
    size_t size;
    size_t capacity;
} Vector;

// Create a vector with initial capacity
Vector *create_vector(size_t capacity) {
    Vector *vec = (Vector *)malloc(sizeof(Vector));
    vec->data = (Element *)calloc(capacity, sizeof(Element));  // Initialize to zero
    vec->size = capacity;
    vec->capacity = capacity;
    return vec;
}

// Free the vector
void free_vector(Vector *vec) {
    free(vec->data);
    free(vec);
}

// Resize the vector if needed
void resize_vector(Vector *vec, size_t new_capacity) {
    vec->data = (Element *)realloc(vec->data, new_capacity * sizeof(Element));
    
    // Initialize the new elements to zero
    memset(&vec->data[vec->capacity], 0, (new_capacity - vec->capacity) * sizeof(Element));
    vec->capacity = new_capacity;
}

// Increment client count for the given user_id, resizing if necessary
void increment_client_count(Vector *vec, int user_id) {
    if (user_id >= vec->capacity) {
        // Resize vector to accommodate the new user_id
        resize_vector(vec, user_id + 1);  // Increase capacity by the new user_id + 1
    }

    vec->data[user_id].user_id = user_id;
    vec->data[user_id].client_count++;

    printf("User ID %d now has %d clients connected.\n", user_id, vec->data[user_id].client_count);
}

// Decrement client count for the given user_id
void decrement_client_count(Vector *vec, int user_id) {
    if (user_id < vec->capacity) {
        vec->data[user_id].client_count--;

        if (vec->data[user_id].client_count < 0) {
            vec->data[user_id].client_count = 0;  // Ensure no negative count
        }

        printf("User ID %d now has %d clients connected.\n", user_id, vec->data[user_id].client_count);
    }
}

// Get the current client count for a specific user_id
int get_client_count(Vector *vec, int user_id) {
    if (user_id < vec->capacity) {
        return vec->data[user_id].client_count;
    }
    return 0;
}
  // Function to resize the vector

#endif

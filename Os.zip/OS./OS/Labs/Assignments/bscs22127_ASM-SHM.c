#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <pthread.h>

typedef struct {
    int entry1;
} Element;

typedef struct {
    Element Buffer[10];
    int si; // Start index
    int ei; // End index
    sem_t isFull;   
    sem_t isEmpty; 
    pthread_mutex_t mutex; 
} Shared_memory;

void producer(Shared_memory *shm) {
    for (int i = 0; i < 15; ++i) {
        sem_wait(&shm->isEmpty); 
        pthread_mutex_lock(&shm->mutex); 

        // Produce an item
        shm->Buffer[shm->ei].entry1 = i;
        printf("Producer: Produced %d\n", i);

        // Update end index
        shm->ei = (shm->ei + 1) % 10;

        pthread_mutex_unlock(&shm->mutex); 
        sem_post(&shm->isFull); 
    }
}

void consumer(Shared_memory *shm) {
    for (int i = 0; i < 15; ++i) {
        sem_wait(&shm->isFull); 
        pthread_mutex_lock(&shm->mutex); 

        // Consume an item
        int consumed = shm->Buffer[shm->si].entry1;
        printf("Consumer: Consumed %d\n", consumed);

        // Update start index
        shm->si = (shm->si + 1) % 10;

        pthread_mutex_unlock(&shm->mutex);
        sem_post(&shm->isEmpty); 
        sleep(1); 
    }
}

int main() 
{
    size_t shm_size = sizeof(Shared_memory);

    // Create a shared memory region
    Shared_memory *shm = mmap(NULL, shm_size, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (shm == MAP_FAILED) {
        perror("Error creating shared memory");
        return 1;
    }

    // Initialize shared memory
    shm->si = 0;
    shm->ei = 0;
    sem_init(&shm->isFull, 1, 0); 
    sem_init(&shm->isEmpty, 1, 10); 
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED);
    pthread_mutex_init(&shm->mutex, &attr);

    pid_t pid = fork();

    if (pid == 0) {
        // Child process (Producer)
        producer(shm);
        sem_destroy(&shm->isFull);
        sem_destroy(&shm->isEmpty);
        pthread_mutex_destroy(&shm->mutex);
    } else {
        // Parent process (Consumer)
        consumer(shm);
        wait(NULL);
        munmap(shm, shm_size);
    }

    return 0;
}

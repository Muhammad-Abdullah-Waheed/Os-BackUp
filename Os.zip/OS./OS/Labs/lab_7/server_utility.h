#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <pthread.h>
#include <errno.h>
#include "Queue.h"
#include <semaphore.h>

#define PORT 11001
#define BUFFER_SIZE 1024
#define STORAGE_LIMIT 10240 // 10 KB
#define SERVER_DIR "/home/abdullah/Desktop/OS/Labs/lab_7/server_files/"
#define CLIENTS_FILE "/home/abdullah/Desktop/OS/Labs/lab_7/server_files/clients_info.txt"

Queue* request_queue;



pthread_mutex_t queue_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t read_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t write_lock = PTHREAD_MUTEX_INITIALIZER;
sem_t request_sem ;



int reader_count = 0;


void handle_client(int new_socket);
void handle_upload(int new_socket, const char *file_name, char *client_dir);
void handle_download(int new_socket, const char *file_name, char *client_dir);
void handle_view(int new_socket, char *client_dir);
void *client_handler(void *socket);
int authenticate_client(int new_socket, char *client_dir,char *username,char *pasword);

// Reader function
void start_read() {
    pthread_mutex_lock(&read_lock);
    reader_count++;
    if (reader_count == 1) {
        pthread_mutex_lock(&write_lock);  // Block writers if there is a reader
    }
    pthread_mutex_unlock(&read_lock);
}

void end_read() {
    pthread_mutex_lock(&read_lock);
    reader_count--;
    if (reader_count == 0) {
        pthread_mutex_unlock(&write_lock);  // Allow writers when no readers
    }
    pthread_mutex_unlock(&read_lock);
}

// Writer function
void start_write() {
    pthread_mutex_lock(&write_lock);  // Block all readers and writers
}

void end_write() {
    pthread_mutex_unlock(&write_lock);
}


void setup_server() {
    // Create thread pool to process requests
    pthread_t worker_threads[2];  // Number of worker threads to handle requests
    for (int i = 0; i < 2; i++) {
        pthread_create(&worker_threads[i], NULL, process_requests, NULL);
    }
}






